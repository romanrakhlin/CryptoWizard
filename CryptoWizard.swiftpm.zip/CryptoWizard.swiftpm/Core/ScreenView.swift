//
//  ScreenView.swift
//  CryptoWizard
//
//  Created by Roman Rakhlin on 4/23/22.
//

import Foundation

// Model
struct ScreenView {
    let text: String
    let image: String
}
